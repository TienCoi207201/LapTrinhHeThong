﻿
namespace YuTang_App.Src.Panel
{
    partial class pnReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(pnReport));
            this.TabControl1 = new System.Windows.Forms.TabControl();
            this.DoanhThu = new System.Windows.Forms.TabPage();
            this.btnChart_DT = new System.Windows.Forms.Button();
            this.btnRef_DT = new System.Windows.Forms.Button();
            this.cbbLoai_DT = new System.Windows.Forms.ComboBox();
            this.cbbMonth_DT = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lbDT2 = new System.Windows.Forms.Label();
            this.lbDT1 = new System.Windows.Forms.Label();
            this.btnExcel_DT = new System.Windows.Forms.Button();
            this.dtEnd_DT = new System.Windows.Forms.DateTimePicker();
            this.dtStart_DT = new System.Windows.Forms.DateTimePicker();
            this.lbTotal_DT = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvDoanhThu = new System.Windows.Forms.DataGridView();
            this.MonAn = new System.Windows.Forms.TabPage();
            this.btnChart_F = new System.Windows.Forms.Button();
            this.btnRef_F = new System.Windows.Forms.Button();
            this.cbbLoai_F = new System.Windows.Forms.ComboBox();
            this.cbbMonth_F = new System.Windows.Forms.ComboBox();
            this.lbF2 = new System.Windows.Forms.Label();
            this.lbF1 = new System.Windows.Forms.Label();
            this.btnExcel_F = new System.Windows.Forms.Button();
            this.dtEnd_F = new System.Windows.Forms.DateTimePicker();
            this.dtStart_F = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.dgvFood = new System.Windows.Forms.DataGridView();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnChart_NV = new System.Windows.Forms.Button();
            this.btnRef_NV = new System.Windows.Forms.Button();
            this.cbbLoai_NV = new System.Windows.Forms.ComboBox();
            this.cbbMonth_NV = new System.Windows.Forms.ComboBox();
            this.lbNV2 = new System.Windows.Forms.Label();
            this.lbNV1 = new System.Windows.Forms.Label();
            this.btnExcel_NV = new System.Windows.Forms.Button();
            this.dtEnd_NV = new System.Windows.Forms.DateTimePicker();
            this.dtStart_NV = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.dgvNV = new System.Windows.Forms.DataGridView();
            this.TongTien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayHD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenKH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenNV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaHD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TabControl1.SuspendLayout();
            this.DoanhThu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoanhThu)).BeginInit();
            this.MonAn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFood)).BeginInit();
            this.tabPage1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNV)).BeginInit();
            this.SuspendLayout();
            // 
            // TabControl1
            // 
            this.TabControl1.Controls.Add(this.DoanhThu);
            this.TabControl1.Controls.Add(this.MonAn);
            this.TabControl1.Controls.Add(this.tabPage1);
            this.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TabControl1.Location = new System.Drawing.Point(0, 0);
            this.TabControl1.Name = "TabControl1";
            this.TabControl1.SelectedIndex = 0;
            this.TabControl1.Size = new System.Drawing.Size(1197, 838);
            this.TabControl1.TabIndex = 0;
            this.TabControl1.SelectedIndexChanged += new System.EventHandler(this.TabControl1_SelectedIndexChanged);
            // 
            // DoanhThu
            // 
            this.DoanhThu.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.DoanhThu.Controls.Add(this.btnChart_DT);
            this.DoanhThu.Controls.Add(this.btnRef_DT);
            this.DoanhThu.Controls.Add(this.cbbLoai_DT);
            this.DoanhThu.Controls.Add(this.cbbMonth_DT);
            this.DoanhThu.Controls.Add(this.label5);
            this.DoanhThu.Controls.Add(this.lbDT2);
            this.DoanhThu.Controls.Add(this.lbDT1);
            this.DoanhThu.Controls.Add(this.btnExcel_DT);
            this.DoanhThu.Controls.Add(this.dtEnd_DT);
            this.DoanhThu.Controls.Add(this.dtStart_DT);
            this.DoanhThu.Controls.Add(this.lbTotal_DT);
            this.DoanhThu.Controls.Add(this.label2);
            this.DoanhThu.Controls.Add(this.label1);
            this.DoanhThu.Controls.Add(this.dgvDoanhThu);
            this.DoanhThu.Location = new System.Drawing.Point(4, 29);
            this.DoanhThu.Name = "DoanhThu";
            this.DoanhThu.Padding = new System.Windows.Forms.Padding(3);
            this.DoanhThu.Size = new System.Drawing.Size(1189, 805);
            this.DoanhThu.TabIndex = 0;
            this.DoanhThu.Text = "Doanh Thu";
            // 
            // btnChart_DT
            // 
            this.btnChart_DT.Image = ((System.Drawing.Image)(resources.GetObject("btnChart_DT.Image")));
            this.btnChart_DT.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnChart_DT.Location = new System.Drawing.Point(863, 153);
            this.btnChart_DT.Name = "btnChart_DT";
            this.btnChart_DT.Size = new System.Drawing.Size(150, 41);
            this.btnChart_DT.TabIndex = 23;
            this.btnChart_DT.Text = "Đồ Thị";
            this.btnChart_DT.UseVisualStyleBackColor = true;
            this.btnChart_DT.Click += new System.EventHandler(this.btnChartDT_Click);
            // 
            // btnRef_DT
            // 
            this.btnRef_DT.Image = ((System.Drawing.Image)(resources.GetObject("btnRef_DT.Image")));
            this.btnRef_DT.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRef_DT.Location = new System.Drawing.Point(1031, 82);
            this.btnRef_DT.Name = "btnRef_DT";
            this.btnRef_DT.Size = new System.Drawing.Size(150, 41);
            this.btnRef_DT.TabIndex = 21;
            this.btnRef_DT.Text = "Làm Mới";
            this.btnRef_DT.UseVisualStyleBackColor = true;
            this.btnRef_DT.Click += new System.EventHandler(this.btnRef_DT_Click);
            // 
            // cbbLoai_DT
            // 
            this.cbbLoai_DT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbbLoai_DT.FormattingEnabled = true;
            this.cbbLoai_DT.Items.AddRange(new object[] {
            "Theo Tháng",
            "Tùy Chọn",
            "Theo Năm"});
            this.cbbLoai_DT.Location = new System.Drawing.Point(675, 85);
            this.cbbLoai_DT.Name = "cbbLoai_DT";
            this.cbbLoai_DT.Size = new System.Drawing.Size(158, 33);
            this.cbbLoai_DT.TabIndex = 19;
            this.cbbLoai_DT.SelectedIndexChanged += new System.EventHandler(this.cbbDTLoai_SelectedIndexChanged);
            // 
            // cbbMonth_DT
            // 
            this.cbbMonth_DT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbbMonth_DT.FormattingEnabled = true;
            this.cbbMonth_DT.Location = new System.Drawing.Point(675, 156);
            this.cbbMonth_DT.Name = "cbbMonth_DT";
            this.cbbMonth_DT.Size = new System.Drawing.Size(158, 33);
            this.cbbMonth_DT.TabIndex = 18;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(448, 35);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(261, 29);
            this.label5.TabIndex = 9;
            this.label5.Text = "Thống Kê Doanh Thu";
            // 
            // lbDT2
            // 
            this.lbDT2.AutoSize = true;
            this.lbDT2.Location = new System.Drawing.Point(352, 163);
            this.lbDT2.Name = "lbDT2";
            this.lbDT2.Size = new System.Drawing.Size(92, 20);
            this.lbDT2.TabIndex = 8;
            this.lbDT2.Text = "Đến Ngày :";
            // 
            // lbDT1
            // 
            this.lbDT1.AutoSize = true;
            this.lbDT1.Location = new System.Drawing.Point(33, 163);
            this.lbDT1.Name = "lbDT1";
            this.lbDT1.Size = new System.Drawing.Size(81, 20);
            this.lbDT1.TabIndex = 7;
            this.lbDT1.Text = "Từ Ngày :";
            // 
            // btnExcel_DT
            // 
            this.btnExcel_DT.Image = ((System.Drawing.Image)(resources.GetObject("btnExcel_DT.Image")));
            this.btnExcel_DT.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExcel_DT.Location = new System.Drawing.Point(1031, 153);
            this.btnExcel_DT.Name = "btnExcel_DT";
            this.btnExcel_DT.Size = new System.Drawing.Size(150, 41);
            this.btnExcel_DT.TabIndex = 6;
            this.btnExcel_DT.Text = "Xuất Excel";
            this.btnExcel_DT.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExcel_DT.UseVisualStyleBackColor = true;
            this.btnExcel_DT.Click += new System.EventHandler(this.btnExcelDT_Click);
            // 
            // dtEnd_DT
            // 
            this.dtEnd_DT.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtEnd_DT.Location = new System.Drawing.Point(461, 158);
            this.dtEnd_DT.Name = "dtEnd_DT";
            this.dtEnd_DT.Size = new System.Drawing.Size(163, 27);
            this.dtEnd_DT.TabIndex = 5;
            // 
            // dtStart_DT
            // 
            this.dtStart_DT.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtStart_DT.Location = new System.Drawing.Point(142, 158);
            this.dtStart_DT.Name = "dtStart_DT";
            this.dtStart_DT.Size = new System.Drawing.Size(156, 27);
            this.dtStart_DT.TabIndex = 4;
            // 
            // lbTotal_DT
            // 
            this.lbTotal_DT.AutoSize = true;
            this.lbTotal_DT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTotal_DT.Location = new System.Drawing.Point(839, 731);
            this.lbTotal_DT.Name = "lbTotal_DT";
            this.lbTotal_DT.Size = new System.Drawing.Size(0, 25);
            this.lbTotal_DT.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1088, 731);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "VND";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(712, 731);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Tổng Tiền :";
            // 
            // dgvDoanhThu
            // 
            this.dgvDoanhThu.AllowUserToAddRows = false;
            this.dgvDoanhThu.AllowUserToDeleteRows = false;
            this.dgvDoanhThu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDoanhThu.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dgvDoanhThu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDoanhThu.Location = new System.Drawing.Point(8, 230);
            this.dgvDoanhThu.Name = "dgvDoanhThu";
            this.dgvDoanhThu.ReadOnly = true;
            this.dgvDoanhThu.RowHeadersWidth = 51;
            this.dgvDoanhThu.RowTemplate.Height = 24;
            this.dgvDoanhThu.Size = new System.Drawing.Size(1173, 464);
            this.dgvDoanhThu.TabIndex = 0;
            // 
            // MonAn
            // 
            this.MonAn.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.MonAn.Controls.Add(this.btnChart_F);
            this.MonAn.Controls.Add(this.btnRef_F);
            this.MonAn.Controls.Add(this.cbbLoai_F);
            this.MonAn.Controls.Add(this.cbbMonth_F);
            this.MonAn.Controls.Add(this.lbF2);
            this.MonAn.Controls.Add(this.lbF1);
            this.MonAn.Controls.Add(this.btnExcel_F);
            this.MonAn.Controls.Add(this.dtEnd_F);
            this.MonAn.Controls.Add(this.dtStart_F);
            this.MonAn.Controls.Add(this.label6);
            this.MonAn.Controls.Add(this.dgvFood);
            this.MonAn.Location = new System.Drawing.Point(4, 29);
            this.MonAn.Name = "MonAn";
            this.MonAn.Padding = new System.Windows.Forms.Padding(3);
            this.MonAn.Size = new System.Drawing.Size(1189, 805);
            this.MonAn.TabIndex = 1;
            this.MonAn.Text = "Món Ăn Hot";
            // 
            // btnChart_F
            // 
            this.btnChart_F.Image = ((System.Drawing.Image)(resources.GetObject("btnChart_F.Image")));
            this.btnChart_F.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnChart_F.Location = new System.Drawing.Point(851, 181);
            this.btnChart_F.Name = "btnChart_F";
            this.btnChart_F.Size = new System.Drawing.Size(150, 41);
            this.btnChart_F.TabIndex = 32;
            this.btnChart_F.Text = "Đồ Thị";
            this.btnChart_F.UseVisualStyleBackColor = true;
            this.btnChart_F.Click += new System.EventHandler(this.btnChart_F_Click);
            // 
            // btnRef_F
            // 
            this.btnRef_F.Image = ((System.Drawing.Image)(resources.GetObject("btnRef_F.Image")));
            this.btnRef_F.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRef_F.Location = new System.Drawing.Point(1019, 110);
            this.btnRef_F.Name = "btnRef_F";
            this.btnRef_F.Size = new System.Drawing.Size(150, 41);
            this.btnRef_F.TabIndex = 31;
            this.btnRef_F.Text = "Làm Mới";
            this.btnRef_F.UseVisualStyleBackColor = true;
            this.btnRef_F.Click += new System.EventHandler(this.btnRef_F_Click);
            // 
            // cbbLoai_F
            // 
            this.cbbLoai_F.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbbLoai_F.FormattingEnabled = true;
            this.cbbLoai_F.Items.AddRange(new object[] {
            "Theo Tháng",
            "Tùy Chọn",
            "Theo Năm"});
            this.cbbLoai_F.Location = new System.Drawing.Point(663, 113);
            this.cbbLoai_F.Name = "cbbLoai_F";
            this.cbbLoai_F.Size = new System.Drawing.Size(158, 33);
            this.cbbLoai_F.TabIndex = 30;
            this.cbbLoai_F.SelectedIndexChanged += new System.EventHandler(this.cbbLoai_F_SelectedIndexChanged);
            // 
            // cbbMonth_F
            // 
            this.cbbMonth_F.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbbMonth_F.FormattingEnabled = true;
            this.cbbMonth_F.Location = new System.Drawing.Point(663, 184);
            this.cbbMonth_F.Name = "cbbMonth_F";
            this.cbbMonth_F.Size = new System.Drawing.Size(158, 33);
            this.cbbMonth_F.TabIndex = 29;
            // 
            // lbF2
            // 
            this.lbF2.AutoSize = true;
            this.lbF2.Location = new System.Drawing.Point(340, 191);
            this.lbF2.Name = "lbF2";
            this.lbF2.Size = new System.Drawing.Size(92, 20);
            this.lbF2.TabIndex = 28;
            this.lbF2.Text = "Đến Ngày :";
            // 
            // lbF1
            // 
            this.lbF1.AutoSize = true;
            this.lbF1.Location = new System.Drawing.Point(21, 191);
            this.lbF1.Name = "lbF1";
            this.lbF1.Size = new System.Drawing.Size(81, 20);
            this.lbF1.TabIndex = 27;
            this.lbF1.Text = "Từ Ngày :";
            // 
            // btnExcel_F
            // 
            this.btnExcel_F.Image = ((System.Drawing.Image)(resources.GetObject("btnExcel_F.Image")));
            this.btnExcel_F.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExcel_F.Location = new System.Drawing.Point(1019, 181);
            this.btnExcel_F.Name = "btnExcel_F";
            this.btnExcel_F.Size = new System.Drawing.Size(150, 41);
            this.btnExcel_F.TabIndex = 26;
            this.btnExcel_F.Text = "Xuất Excel";
            this.btnExcel_F.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExcel_F.UseVisualStyleBackColor = true;
            this.btnExcel_F.Click += new System.EventHandler(this.btnExcel_F_Click);
            // 
            // dtEnd_F
            // 
            this.dtEnd_F.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtEnd_F.Location = new System.Drawing.Point(449, 186);
            this.dtEnd_F.Name = "dtEnd_F";
            this.dtEnd_F.Size = new System.Drawing.Size(163, 27);
            this.dtEnd_F.TabIndex = 25;
            // 
            // dtStart_F
            // 
            this.dtStart_F.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtStart_F.Location = new System.Drawing.Point(130, 186);
            this.dtStart_F.Name = "dtStart_F";
            this.dtStart_F.Size = new System.Drawing.Size(156, 27);
            this.dtStart_F.TabIndex = 24;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(445, 44);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(268, 29);
            this.label6.TabIndex = 16;
            this.label6.Text = "Thống Kê Món Ăn Hot";
            // 
            // dgvFood
            // 
            this.dgvFood.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvFood.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dgvFood.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFood.Location = new System.Drawing.Point(8, 265);
            this.dgvFood.Name = "dgvFood";
            this.dgvFood.RowHeadersWidth = 51;
            this.dgvFood.RowTemplate.Height = 24;
            this.dgvFood.Size = new System.Drawing.Size(1173, 532);
            this.dgvFood.TabIndex = 10;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1189, 805);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "Nhân Viên";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel1.Controls.Add(this.btnChart_NV);
            this.panel1.Controls.Add(this.btnRef_NV);
            this.panel1.Controls.Add(this.cbbLoai_NV);
            this.panel1.Controls.Add(this.cbbMonth_NV);
            this.panel1.Controls.Add(this.lbNV2);
            this.panel1.Controls.Add(this.lbNV1);
            this.panel1.Controls.Add(this.btnExcel_NV);
            this.panel1.Controls.Add(this.dtEnd_NV);
            this.panel1.Controls.Add(this.dtStart_NV);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.dgvNV);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1183, 799);
            this.panel1.TabIndex = 0;
            // 
            // btnChart_NV
            // 
            this.btnChart_NV.Image = ((System.Drawing.Image)(resources.GetObject("btnChart_NV.Image")));
            this.btnChart_NV.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnChart_NV.Location = new System.Drawing.Point(849, 180);
            this.btnChart_NV.Name = "btnChart_NV";
            this.btnChart_NV.Size = new System.Drawing.Size(150, 41);
            this.btnChart_NV.TabIndex = 43;
            this.btnChart_NV.Text = "Đồ Thị";
            this.btnChart_NV.UseVisualStyleBackColor = true;
            this.btnChart_NV.Click += new System.EventHandler(this.btnChart_NV_Click);
            // 
            // btnRef_NV
            // 
            this.btnRef_NV.Image = ((System.Drawing.Image)(resources.GetObject("btnRef_NV.Image")));
            this.btnRef_NV.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRef_NV.Location = new System.Drawing.Point(1017, 109);
            this.btnRef_NV.Name = "btnRef_NV";
            this.btnRef_NV.Size = new System.Drawing.Size(150, 41);
            this.btnRef_NV.TabIndex = 42;
            this.btnRef_NV.Text = "Làm Mới";
            this.btnRef_NV.UseVisualStyleBackColor = true;
            this.btnRef_NV.Click += new System.EventHandler(this.btnRef_NV_Click);
            // 
            // cbbLoai_NV
            // 
            this.cbbLoai_NV.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbbLoai_NV.FormattingEnabled = true;
            this.cbbLoai_NV.Items.AddRange(new object[] {
            "Theo Tháng",
            "Tùy Chọn",
            "Theo Năm"});
            this.cbbLoai_NV.Location = new System.Drawing.Point(661, 112);
            this.cbbLoai_NV.Name = "cbbLoai_NV";
            this.cbbLoai_NV.Size = new System.Drawing.Size(158, 33);
            this.cbbLoai_NV.TabIndex = 41;
            this.cbbLoai_NV.SelectedIndexChanged += new System.EventHandler(this.cbbLoai_NV_SelectedIndexChanged);
            // 
            // cbbMonth_NV
            // 
            this.cbbMonth_NV.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbbMonth_NV.FormattingEnabled = true;
            this.cbbMonth_NV.Location = new System.Drawing.Point(661, 183);
            this.cbbMonth_NV.Name = "cbbMonth_NV";
            this.cbbMonth_NV.Size = new System.Drawing.Size(158, 33);
            this.cbbMonth_NV.TabIndex = 40;
            // 
            // lbNV2
            // 
            this.lbNV2.AutoSize = true;
            this.lbNV2.Location = new System.Drawing.Point(338, 190);
            this.lbNV2.Name = "lbNV2";
            this.lbNV2.Size = new System.Drawing.Size(92, 20);
            this.lbNV2.TabIndex = 39;
            this.lbNV2.Text = "Đến Ngày :";
            // 
            // lbNV1
            // 
            this.lbNV1.AutoSize = true;
            this.lbNV1.Location = new System.Drawing.Point(19, 190);
            this.lbNV1.Name = "lbNV1";
            this.lbNV1.Size = new System.Drawing.Size(81, 20);
            this.lbNV1.TabIndex = 38;
            this.lbNV1.Text = "Từ Ngày :";
            // 
            // btnExcel_NV
            // 
            this.btnExcel_NV.Image = ((System.Drawing.Image)(resources.GetObject("btnExcel_NV.Image")));
            this.btnExcel_NV.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExcel_NV.Location = new System.Drawing.Point(1017, 180);
            this.btnExcel_NV.Name = "btnExcel_NV";
            this.btnExcel_NV.Size = new System.Drawing.Size(150, 41);
            this.btnExcel_NV.TabIndex = 37;
            this.btnExcel_NV.Text = "Xuất Excel";
            this.btnExcel_NV.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExcel_NV.UseVisualStyleBackColor = true;
            this.btnExcel_NV.Click += new System.EventHandler(this.btnExcel_NV_Click);
            // 
            // dtEnd_NV
            // 
            this.dtEnd_NV.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtEnd_NV.Location = new System.Drawing.Point(447, 185);
            this.dtEnd_NV.Name = "dtEnd_NV";
            this.dtEnd_NV.Size = new System.Drawing.Size(163, 27);
            this.dtEnd_NV.TabIndex = 36;
            // 
            // dtStart_NV
            // 
            this.dtStart_NV.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtStart_NV.Location = new System.Drawing.Point(128, 185);
            this.dtStart_NV.Name = "dtStart_NV";
            this.dtStart_NV.Size = new System.Drawing.Size(156, 27);
            this.dtStart_NV.TabIndex = 35;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(508, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(193, 29);
            this.label7.TabIndex = 34;
            this.label7.Text = "BXH Nhân Viên";
            // 
            // dgvNV
            // 
            this.dgvNV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvNV.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dgvNV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNV.Location = new System.Drawing.Point(5, 270);
            this.dgvNV.Name = "dgvNV";
            this.dgvNV.RowHeadersWidth = 51;
            this.dgvNV.RowTemplate.Height = 24;
            this.dgvNV.Size = new System.Drawing.Size(1173, 506);
            this.dgvNV.TabIndex = 33;
            // 
            // TongTien
            // 
            this.TongTien.DataPropertyName = "TongTien";
            this.TongTien.HeaderText = "Tổng Tiền";
            this.TongTien.MinimumWidth = 6;
            this.TongTien.Name = "TongTien";
            this.TongTien.ReadOnly = true;
            this.TongTien.Width = 125;
            // 
            // NgayHD
            // 
            this.NgayHD.DataPropertyName = "NgayHD";
            this.NgayHD.HeaderText = "Ngày Hóa Đơn";
            this.NgayHD.MinimumWidth = 6;
            this.NgayHD.Name = "NgayHD";
            this.NgayHD.ReadOnly = true;
            this.NgayHD.Width = 125;
            // 
            // TenKH
            // 
            this.TenKH.DataPropertyName = "TenKH";
            this.TenKH.HeaderText = "Tên Khách Hàng";
            this.TenKH.MinimumWidth = 6;
            this.TenKH.Name = "TenKH";
            this.TenKH.ReadOnly = true;
            this.TenKH.Width = 125;
            // 
            // TenNV
            // 
            this.TenNV.DataPropertyName = "TenNV";
            this.TenNV.HeaderText = "Tên Nhân Viên";
            this.TenNV.MinimumWidth = 6;
            this.TenNV.Name = "TenNV";
            this.TenNV.ReadOnly = true;
            this.TenNV.Width = 125;
            // 
            // MaHD
            // 
            this.MaHD.DataPropertyName = "MaHD";
            this.MaHD.HeaderText = "Mã Hóa Đơn";
            this.MaHD.MinimumWidth = 6;
            this.MaHD.Name = "MaHD";
            this.MaHD.ReadOnly = true;
            this.MaHD.Width = 125;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "TongTien";
            this.dataGridViewTextBoxColumn1.HeaderText = "Tổng Tiền";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "NgayHD";
            this.dataGridViewTextBoxColumn2.HeaderText = "Ngày Hóa Đơn";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "TenKH";
            this.dataGridViewTextBoxColumn3.HeaderText = "Tên Khách Hàng";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "TenNV";
            this.dataGridViewTextBoxColumn4.HeaderText = "Tên Nhân Viên";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "MaHD";
            this.dataGridViewTextBoxColumn5.HeaderText = "Mã Hóa Đơn";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // pnReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(1197, 838);
            this.Controls.Add(this.TabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "pnReport";
            this.Text = "pnReport";
            this.Load += new System.EventHandler(this.pnReport_Load);
            this.TabControl1.ResumeLayout(false);
            this.DoanhThu.ResumeLayout(false);
            this.DoanhThu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoanhThu)).EndInit();
            this.MonAn.ResumeLayout(false);
            this.MonAn.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFood)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNV)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabControl TabControl1;
        private System.Windows.Forms.TabPage MonAn;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dgvFood;
        private System.Windows.Forms.Button btnChart_F;
        private System.Windows.Forms.Button btnRef_F;
        private System.Windows.Forms.ComboBox cbbLoai_F;
        private System.Windows.Forms.ComboBox cbbMonth_F;
        private System.Windows.Forms.Label lbF2;
        private System.Windows.Forms.Label lbF1;
        private System.Windows.Forms.Button btnExcel_F;
        private System.Windows.Forms.DateTimePicker dtEnd_F;
        private System.Windows.Forms.DateTimePicker dtStart_F;
        private System.Windows.Forms.TabPage DoanhThu;
        private System.Windows.Forms.Button btnChart_DT;
        private System.Windows.Forms.Button btnRef_DT;
        private System.Windows.Forms.ComboBox cbbLoai_DT;
        private System.Windows.Forms.ComboBox cbbMonth_DT;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbDT2;
        private System.Windows.Forms.Label lbDT1;
        private System.Windows.Forms.Button btnExcel_DT;
        private System.Windows.Forms.DateTimePicker dtEnd_DT;
        private System.Windows.Forms.DateTimePicker dtStart_DT;
        private System.Windows.Forms.Label lbTotal_DT;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvDoanhThu;
        private System.Windows.Forms.DataGridViewTextBoxColumn TongTien;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayHD;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenKH;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenNV;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHD;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnChart_NV;
        private System.Windows.Forms.Button btnRef_NV;
        private System.Windows.Forms.ComboBox cbbLoai_NV;
        private System.Windows.Forms.ComboBox cbbMonth_NV;
        private System.Windows.Forms.Label lbNV2;
        private System.Windows.Forms.Label lbNV1;
        private System.Windows.Forms.Button btnExcel_NV;
        private System.Windows.Forms.DateTimePicker dtEnd_NV;
        private System.Windows.Forms.DateTimePicker dtStart_NV;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dgvNV;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
    }
}